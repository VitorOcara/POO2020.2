
package Conexao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import model.Player;

public class PlayerConecta {

    private final Connection connection;

    public PlayerConecta(Connection connection) {
        this.connection = connection;
    }
    
    public void insert(Player player) throws SQLException{
        String sql = ("insert into player(nome, lvl, dinheiro, def, atk, hp_atual, hp_max, velocidade, xp) values (?, ?, ?, ?, ?, ?, ?, ?, ?)");

        PreparedStatement statement = connection.prepareStatement(sql);
        statement.setString(1, player.getNome());
        statement.setInt(2, player.getLvl());
        statement.setFloat(3,player.getMoney());
        statement.setInt(4, player.getDef());
        statement.setInt(5, player.getAtk());
        statement.setInt(6, player.getHp_atual());
        statement.setInt(7, player.getHp_max());
        statement.setInt(8, player.getVelocidade());
        statement.setInt(9, player.getXp());
        statement.execute();       
        connection.close(); 
         
    }
    
    public void delete(int id) throws SQLException{
        
        String sql = ("delete from player where id = ?;");
        
        PreparedStatement statement = connection.prepareStatement(sql);
        
        statement.setInt(1, id);
        statement.execute();       
        connection.close(); 
     
    }
    
    
    //updates 
    
    public void updateNome(String nome, int id) throws SQLException{
        
        String sql = ("update player set nome = ? where id = ?");
        
        
        PreparedStatement statement = connection.prepareStatement(sql);

        statement.setString(1, nome);
        statement.setInt(2, id);
        statement.execute();       
        connection.close(); 

    }
    public void updatePlayer(Player p) throws SQLException{
        
        String sql = ("update player set lvl = ?, atk =  ? , def =  ? ,"
                + " hp_max = ?, hp_atual = ? ,velocidade = ?, dinheiro = ?, xp = ?  where id = ?");
        
        PreparedStatement statement = connection.prepareStatement(sql);
        statement.setInt(1, p.getLvl());
        statement.setInt(2, p.getAtk());
        statement.setInt(3, p.getDef());
        statement.setInt(4, p.getHp_max());
        statement.setInt(5, p.getHp_atual());
        statement.setInt(6, p.getVelocidade());
        statement.setFloat(7, p.getMoney());
        statement.setInt(8, p.getXp());
        statement.setInt(9, p.getId());
        statement.execute();
        connection.close();   
    }

    
        
    //select
    public Player Load(int id, Player pl) throws SQLException{
        String sql = ("Select * from player where id = ?");
        
        PreparedStatement statement = connection.prepareStatement(sql);
        statement.setInt(1, id);
        statement.execute();
        
        ResultSet resultSet = statement.getResultSet();
        String nome = resultSet.getString("nome");
        int lvl = resultSet.getInt("lvl");
        int hp_atual = resultSet.getInt("hp_atual");
        int xp = resultSet.getInt("xp");
        int atk = resultSet.getInt("atk");
        int def = resultSet.getInt("def");
        int hp_max = resultSet.getInt("hp_max");
        int velocidade = resultSet.getInt("velocidade");
        float money = resultSet.getFloat("dinheiro");
        
        Player p = new Player(nome, lvl, money, xp, atk, def, hp_max, hp_atual, velocidade);
        connection.close();
        return p;
    }
    
    
    public ArrayList<Player> selectAll() throws SQLException{        
        String sql = ("Select * from player order by id");
        
        PreparedStatement statement = connection.prepareStatement(sql);
        statement.execute();
        ResultSet resultSet = statement.getResultSet();
        
        ArrayList<Player> player = new ArrayList<>();
        
        while(resultSet.next()){
            
            int id = resultSet.getInt("id");
            String nome = resultSet.getString("nome");
            int lvl = resultSet.getInt("lvl");
            int hp_atual = resultSet.getInt("hp_atual");
            int xp = resultSet.getInt("xp");
            int atk = resultSet.getInt("atk");
            int def = resultSet.getInt("def");
            int hp_max = resultSet.getInt("hp_max");
            int velocidade = resultSet.getInt("velocidade");
            float money = resultSet.getFloat("dinheiro");
        
        Player pDados = new Player(id, nome, lvl, money, xp, atk, def, hp_max, hp_atual, velocidade);
            player.add(pDados);
        }
        return player;
    }

}
