
package model;

public class Lobo extends Mobs{
    
    public Lobo(String nome, int lvl) {
        //    nome, lvl,  xp,    hp,    atk,   def,  vel,   money
        super(nome, lvl, lvl+5, lvl*4, lvl + 3, lvl, lvl+3, lvl *10);
    }
    
}
