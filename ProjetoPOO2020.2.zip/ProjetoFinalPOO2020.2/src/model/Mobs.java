
package model;


public class Mobs implements Ações.AcaoMob{
    private String nome;
    private int lvl;
    private int xp;
    private int hp;
    private int hp_atual;
    private int atk;
    private int def;
    private int vel;
    private float gold;

    public float getGold() {
        return gold;
    }

    public void setGold(float gold) {
        this.gold = gold;
    }
    
    
    public int getVel() {
        return vel;
    }

    public void setVel(int vel) {
        this.vel = vel;
    }

    public int getHp_atual() {
        return hp_atual;
    }

    public void setHp_atual(int hp_atual) {
        this.hp_atual = hp_atual;
    }
       
    public Mobs(String nome, int lvl, int xp, int hp, int atk, int def, int vel, float money) {
        this.nome = nome;
        this.lvl = lvl;
        this.xp = xp;
        this.hp = hp;
        this.atk = atk;
        this.def = def;
        this.hp_atual = hp;
        this.vel = vel;
        this.gold = money;
    }
    

    public Mobs(String nome, int lvl) {
        this.nome = nome;
        this.lvl = lvl;
        this.xp = lvl * 5;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getLvl() {
        return lvl;
    }

    public int getHp() {
        return hp;
    }

    public void setHp(int hp) {
        this.hp = hp;
    }

    public int getAtk() {
        return atk;
    }

    public void setAtk(int atk) {
        this.atk = atk;
    }

    public int getDef() {
        return def;
    }

    public void setDef(int def) {
        this.def = def;
    }

    public void setLvl(int lvl) {
        this.lvl = lvl;
    }

    public int getXp() {
        return xp;
    }

    public void setXp(int xp) {
        this.xp = xp;
    }
    
    
    
    
     @Override
    public void atacar(Player p) {
        int dano = getAtk() - p.getDef();
        if (dano <= 0) {
            dano = 1;
        }
        p.recebeAtk(dano);
    }
    
  
    @Override
    public void recebeAtk(int dano) {
        setHp_atual(getHp_atual() - dano);
    }

 

    
}
