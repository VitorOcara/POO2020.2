
package model;

import java.util.Random;

import view.Atualizar;

public class Player implements Ações.AcaoPlayer{
    
    Random gerador = new Random();
    private int id;
    private String nome;
    private int lvl;
    private float money;
    private int xp;
    private int atk;
    private int def;
    private int hp_max;
    private int hp_atual;
    private int velocidade;



    public Player(String nome,int lvl) {
        this.nome = nome;
        this.lvl = lvl;
    }

    public Player(int id, String nome, int lvl, float money) {
        this.id = id;
        this.nome = nome;
        this.lvl = lvl;
        this.money = money;
    }

    public Player(int id, String nome, int lvl) {
        this.id = id;
        this.nome = nome;
    }
     
    public Player(String nome, int lvl, int xp, int hp_att) {
            this.xp = xp;
            this.nome = nome;
            
    }
    
    
    public Player(String nome, int lvl, int xp) {
        this.xp = xp;
        this.nome = nome;
    }
    

    public Player(int id, String nome, int lvl, float money, int xp) {
        this.id = id;
        this.nome = nome;
        this.lvl = lvl;
        this.money = money;
        this.xp = xp;
    }

    public Player(int id, String nome, int lvl, float money, int xp, int atk, int def, int hp_max, int hp_atual, int velocidade) {
        this.id = id;
        this.nome = nome;
        this.lvl = lvl;
        this.money = money;
        this.xp = xp;
        this.atk = atk;
        this.def = def;
        this.hp_max = hp_max;
        this.hp_atual = hp_atual;
        this.velocidade = velocidade;
    }

    
    public Player(String nome, int lvl, float money, int xp, int atk, int def, int hp_max, int hp_atual, int velocidade) {
        this.nome = nome;
        this.lvl = lvl;
        this.money = money;
        this.xp = xp;
        this.atk = atk;
        this.def = def;
        this.hp_max = hp_max;
        this.hp_atual = hp_atual;
        this.velocidade = velocidade;
    }
    
    

    public Player(String nome, int lvl, float money, int xp) {
        this.nome = nome;
        this.lvl = lvl;
        this.money = money;
        this.xp = xp;
    }
    
    public int getAtk() {
        return atk;
    }

    public void setAtk(int atk) {
        this.atk = atk;
    }

    public int getDef() {
        return def;
    }

    public void setDef(int def) {
        this.def = def;
    }

    public int getHp_max() {
        return hp_max;
    }

    public void setHp_max(int hp_max) {
        this.hp_max = hp_max;
    }

    public int getHp_atual() {
        return hp_atual;
    }

    public void setHp_atual(int hp_atual) {
        this.hp_atual = hp_atual;
    }

    public int getVelocidade() {
        return velocidade;
    }

    public void setVelocidade(int velocidade) {
        this.velocidade = velocidade;
    }
    
    
    public int getXp() {
        return xp;
    }

    public void setXp(int xp) {
        this.xp = xp;
    }
    

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getLvl() {
        return lvl;
    }

    public void setLvl(int lvl) {
        this.lvl = lvl;
    }

    public float getMoney() {
        return money;
    }

    public void setMoney(float money) {
        this.money = money;
    }
    
    
    @Override
    public void andar(Player p) {
        System.out.println("Andou");
        int rand = gerador.nextInt(10+1);
        System.out.println(rand);
        if(rand < 4){
            
            System.out.println("Voce encontrou um monstro!!! ");
            Slime s = new Slime("Geleia", gerador.nextInt(3) +1 );
            
            
            System.out.println("Apareceu: "+s.getNome()+ " Lvl: "+s.getLvl());
            p.encontrarMob(p, s);
        }
        else if(rand > 6){
            Lobo l = new Lobo("Lobo Cinzento", gerador.nextInt(3) + 1  );
            System.out.println("Apareceu: "+l.getNome()+ " Lvl: "+l.getLvl());
            p.encontrarMob(p, l);
        }
    }

    @Override
    public void encontrarMob(Player p,Mobs m) {
        
        
        
        while(true){
            
            if(p.getVelocidade() >= m.getVel()){
                System.out.println(p.getNome() +" Ataca "+ m.getNome());
                
                p.atacar(m);
                
                if(m.getHp_atual() <= 0){
                    System.out.println(m.getNome()+ " Morreu em batalha");
                    p.setXp(p.getXp()+ m.getXp());
                    p.setMoney(p.getMoney()+ m.getGold());
                    System.out.println("Ganhou: " + m.getXp() +  " de xp e: " + m.getGold() + " de dinheiro!!");
                    

                    if(p.getXp() >= (p.getLvl()*4 + 20)/2){
                        System.out.println("Voce subiu de nivel");
                        p.upar(p,  p.getLvl() +1);
                        p.setXp(p.getXp()%(p.getLvl()*4 + 20)/2);
                        System.out.println("Hp restaurado e atributos aumentados!!!");
                    }
                break;
                }
                
                System.out.println(m.getNome() +"Hp:"+m.getHp_atual()+"/"+m.getHp() );
                m.atacar(p);
                System.out.println(m.getNome() +" Ataca "+ p.getNome());
                System.out.println(p.getNome()+ " Hp:" + p.getHp_atual()+ "/"+p.getHp_max());
                
                if(p.getHp_atual() <= 0){
                    System.out.println(p.getNome()+ " Morreu em batalha");
                    break;
                }
                        
            }
            else if(m.getVel()> p.getVelocidade()){
                m.atacar(p);
                System.out.println(m.getNome() +" Ataca "+ p.getNome());
                System.out.println(p.getNome()+ " Hp:" + p.getHp_atual()+ "/"+p.getHp_max());
                
                if(p.getHp_atual() <= 0){
                    System.out.println(p.getNome()+ " Morreu em batalha");
                    break;
                }
                
                
                p.atacar(m);
                System.out.println(p.getNome() +" Ataca "+ m.getNome());
                System.out.println(m.getNome() +"Hp:"+m.getHp_atual()+"/"+m.getHp() );
                
                if(m.getHp_atual() <= 0){
                    System.out.println(m.getNome()+ " Morreu em batalha");
                    p.setXp(p.getXp()+ m.getXp());
                    p.setMoney(p.getMoney()+ m.getGold());
                    System.out.println("Ganhou: " + m.getXp() +  " de xp e: " + m.getGold() + " de dinheiro!!");
                    

                    if(p.getXp() >= (p.getLvl()*4 + 20)/2){
                        System.out.println("Voce subiu de nivel");
                        p.upar(p,  p.getLvl() +1);
                        p.setXp(p.getXp()%(p.getLvl()*4 + 20)/2);
                        System.out.println("Hp restaurado e atributos aumentados!!!");
                    }
                break;
                }
               
            }
            
        }
    }

    @Override
    public void atacar(Mobs monstro) {
        int dano = getAtk() - monstro.getDef();
        if (dano <= 0) {
            dano = 1;
        }
        monstro.recebeAtk(dano);
    }

    @Override
    public void recebeAtk(int dano) {
        setHp_atual(getHp_atual()- dano);
    }

    @Override
    public void upar(Player p, int lvl) {
        p.setLvl(lvl);
        p.setAtk(lvl * 5);
        p.setDef(lvl * 4);
        p.setVelocidade(lvl * 3);
        p.setHp_max(lvl * 10);
        p.setHp_atual(p.getHp_max());
        
    }

    @Override
    public void comprar(Item i) {

        if (this.getMoney() < i.getPreco()) {
            System.out.println("Nao é possivel comprar!!");
        } else {
            this.setMoney(this.getMoney()- i.getPreco());
        }
    }

    @Override
    public void salvar(Player p) {
        Atualizar att = new Atualizar();
        att.Atualizar(p);
    }
    

    
}
