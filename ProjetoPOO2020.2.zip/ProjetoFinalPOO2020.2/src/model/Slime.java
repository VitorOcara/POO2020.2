
package model;


public class Slime extends Mobs{
    public Slime(String nome, int lvl) {
        //    nome, lvl,  xp,    hp,    atk,    def,   vel,   money
        super(nome, lvl, lvl+ 3, lvl*3, lvl + 2, lvl, lvl+1, lvl *5);
    }


    
}

