
package model;

public class Pocao extends Item{
    private int cura = 20;
    
    public Pocao(String nome, float preco) {
        super(nome, 100);
    }

    public int getCura() {
        return cura;
    }

    public void setCura(int cura) {
        this.cura = cura;
    }
    
}
