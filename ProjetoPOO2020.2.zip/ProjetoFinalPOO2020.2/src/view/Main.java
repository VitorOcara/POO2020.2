
package view;

import java.util.ArrayList;
import java.util.Scanner;
import model.Player;
import model.Pocao;

public class Main {

    public static void main(String []args){
        Scanner scan = new Scanner(System.in);
        String acao;
        
        ArrayList<Player> jogadores = new ArrayList();
        Load load = new Load();
        jogadores = load.Load(jogadores);
        for(Player p: jogadores){
            System.out.println(p.getNome());
        }
        
        System.out.println("AÇÕES: 'insert', 'update', 'delete', 'select', 'jogar', 'exit'");
        while(true){
            System.out.println("Digite sua ação: ");
            
            
            
            acao = scan.nextLine();
            if(acao.equals("insert")){
                
                System.out.println("Digite o nome do novo player: ");
                
                Player p = new NovoPlayer().NovoPlayer(); 
                jogadores.add(p);
                
            }else if(acao.equals("delete")){
                System.out.println("Digite o id do Player a ser apagado:");
                
                System.out.println("Digite cancelar para sair.");
                String tex = scan.next();
                
                if(!tex.equals("cancelar")){
                    int id = Integer.parseInt(tex);
                    Delete del = new Delete(id);
                }
                
            }else if(acao.equals("select")){
                ViewPlayer select = new ViewPlayer();
            }else if(acao.equals("update")){
                
                Atualizar att = new Atualizar();
                System.out.println("Nome atualizado com sucesso!!");
                
            }else if(acao.equals("exit")){
                break;
            }else if(acao.equals("jogar")){
                
                System.out.println("Qual o nome seu player? ");
                String a = scan.nextLine();
                
                //aqui começa realmente o jogo
                for(Player player : jogadores){
                    if(player.getNome().equals(a)){
                        while (true) {                            
                            System.out.println("Digite sua ação: ('andar', 'status', 'comprar', 'salvar', 'sair')");
                            String escolha = scan.next();
                            
                            if(escolha.equals("andar")){
                                player.andar(player);
                            }else if(escolha.equals("status")){
                                System.out.println("Lvl: "+ player.getLvl() + " HP: "+ player.getHp_atual()+ "/" + player.getHp_max() + 
                                        " ATK: "+ player.getAtk() + " DEF: " + player.getDef()+" Vel:"+ player.getVelocidade() +" Xp:"
                                        + player.getXp()+ " Gold:" + player.getMoney());
                            }else if(escolha.equals("salvar")){
                   
                                Atualizar att = new Atualizar();
                                att.Atualizar(player);
                                System.out.println("Salvo com sucesso");
                                
                            }else if(escolha.equals("comprar")){
                                System.out.println("No momento so tem poção de cura simples! vai querer?? (sim/nao)");
                                String at = scan.next();
                                if(at.equals("sim")){
                                    Pocao p = new Pocao("cura simples", 100);
                                    player.comprar(p);
                                    player.setHp_atual(player.getHp_atual() + p.getCura());
                                    if(player.getHp_atual() > player.getHp_max()){
                                        player.setHp_atual(player.getHp_max());
                                    }
                                    System.out.println("Vida restaurada em 20 pontos");
                                    
                                }else if(at.equals("nao")){
                                    System.out.println("Você que sabe meu amigo");
                                }else {
                                    System.out.println("resposta inválida");
                                }
                                
                                
                            }else if(escolha.equals("sair")){
                                Atualizar att = new Atualizar();
                                att.Atualizar(player);
                                System.out.println("Origado por jogar!! Seu progresso foi salvo!");
                                return;
                            }
                            
                            if(player.getHp_atual() <= 0){
                                System.out.println("VOCE PERDEU :(");
                                Delete del = new Delete(player.getId());
                                
                                break;
                            }
                        }
                    }
                }
                
                
            }else{
                System.out.println("AÇAO INVALIDA!!!");
            }
            
        }
        
        
    }

}
