
package view;

import Conexao.Conexao;
import Conexao.PlayerConecta;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import model.Player;

public class ViewPlayer {
    


    public ViewPlayer() {
        try {
            Connection com = new Conexao().getConnection();
            PlayerConecta p = new PlayerConecta(com);
            
            ArrayList<Player> selectAll = p.selectAll();
            for(Player player : selectAll){
                System.out.println("id: "+ player.getId() + " nome: "+ player.getNome() + 
                        " Lvl: "+ player.getLvl()+" dinheiro:"+ player.getMoney()+
                        " Atk:" +player.getAtk() + " Def:" + player.getDef()+ " HP:"+ player.getHp_atual()+
                         "/" + player.getHp_max()+ " Vel:"+ player.getVelocidade() + " Xp:"+ player.getXp() +"\n");
            }
        } catch (SQLException ex) {
            Logger.getLogger(ViewPlayer.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

}
