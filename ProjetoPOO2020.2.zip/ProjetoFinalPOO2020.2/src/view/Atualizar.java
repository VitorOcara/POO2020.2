
package view;

import Conexao.Conexao;
import Conexao.PlayerConecta;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
import model.Player;

public class Atualizar {
    
    public Atualizar(){
        
    }
    
    public void Atualizar(){
        Scanner scan = new Scanner(System.in);

        System.out.println("Digite o novo nome");
        String nome_new = scan.nextLine();

        System.out.println("Digite o id do player que deseja renomear: ");
        int iden = scan.nextInt();
        Connection con;
        
        try {
            
            con = new Conexao().getConnection();
            
            PlayerConecta player = new PlayerConecta(con);
            
            player.updateNome(nome_new, iden);
            
        } catch (SQLException ex) {
            Logger.getLogger(Atualizar.class.getName()).log(Level.SEVERE, null, ex);
        }
                
        
        
    }
    public void Atualizar(Player p){
                
        Connection conexao;
        
        try {
            
            conexao = new Conexao().getConnection();
            PlayerConecta player = new PlayerConecta(conexao);
            player.updatePlayer(p);
            
        } catch (SQLException ex) {
            Logger.getLogger(Atualizar.class.getName()).log(Level.SEVERE, null, ex);
        }
          
    }
}
