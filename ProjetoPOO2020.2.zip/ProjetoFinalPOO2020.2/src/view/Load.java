
package view;

import Conexao.Conexao;
import Conexao.PlayerConecta;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import model.Player;

public class Load {
    
    public ArrayList Load(ArrayList<Player> jogadores ){
            try {
            Connection com = new Conexao().getConnection();
            PlayerConecta p = new PlayerConecta(com);
            jogadores = p.selectAll();
            
            
        } catch (SQLException ex) {
            Logger.getLogger(ViewPlayer.class.getName()).log(Level.SEVERE, null, ex);
        }
        return jogadores;
    } 
    
    public Player Load(Player p){
        
        try {
            Connection com = new Conexao().getConnection();
            PlayerConecta p1 = new PlayerConecta(com);
            
            p = p1.Load(p.getId(), p);
            
            
        } catch (SQLException ex) {
            Logger.getLogger(ViewPlayer.class.getName()).log(Level.SEVERE, null, ex);
        }
        return p;
    }
}
