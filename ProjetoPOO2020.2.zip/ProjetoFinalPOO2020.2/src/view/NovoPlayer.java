
package view;

import Conexao.Conexao;
import Conexao.PlayerConecta;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
import model.Player;


public class NovoPlayer {
    
    public Player NovoPlayer(){
        
        Scanner scan = new Scanner(System.in);
        String nome = scan.next();
        
        Player p = new Player(nome, 1, 1000, 0, 5, 4, 10, 10, 3);
        
        
        try {
      
            Connection con = new Conexao().getConnection();
            PlayerConecta player = new PlayerConecta(con);
            player.insert(p);
            System.out.println("Player Adicionado com sucesso!!");
            
        } catch (SQLException ex) {
            Logger.getLogger(Delete.class.getName()).log(Level.SEVERE, null, ex);
        }
        return p;
    }
}
