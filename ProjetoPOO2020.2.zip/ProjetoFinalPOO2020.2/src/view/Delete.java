
package view;
import Conexao.Conexao;
import Conexao.PlayerConecta;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Delete {
   
    public Delete(int id){
        

        try {

            Connection con = new Conexao().getConnection();
            PlayerConecta player = new PlayerConecta(con);
            player.delete(id);
            System.out.println("Player Apagado com sucesso!!");
            
        } catch (SQLException ex) {
            Logger.getLogger(Delete.class.getName()).log(Level.SEVERE, null, ex);
        }
        
            
    }
            
            
      
        
}
