
package Ações;
import model.Item;
import model.Mobs;
import model.Player;



public interface AcaoPlayer {
    public void andar(Player p);
    public void encontrarMob(Player p ,Mobs m);
    public void atacar(Mobs p);
    public void recebeAtk(int dano);
    public void upar(Player p, int lvl);
    public void comprar(Item i);
    public void salvar(Player p);
}
