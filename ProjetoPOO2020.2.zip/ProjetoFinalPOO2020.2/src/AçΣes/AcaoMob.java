
package Ações;
import model.Player;

public interface AcaoMob {
    public void atacar(Player p);
    public void recebeAtk(int dano);
}